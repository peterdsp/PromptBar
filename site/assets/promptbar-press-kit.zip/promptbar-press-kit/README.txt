PromptBar, Press Kit
====================

Contents
--------
  BOILERPLATE.txt          One-paragraph "About PromptBar" boilerplate.
  FACT-SHEET.txt           Product fact sheet as a plain-text table.
  logos/                   App icon at every native size (16 to 1024).
                           PNG. Transparent, rounded macOS shape.
  screenshots/             Full-resolution product screenshots.
                           PNG. Retina scale, dark UI.

Usage
-----
These assets are provided for editorial and press coverage of
PromptBar. You may:

  * Use logos and screenshots in articles, reviews, videos, blog
    posts, podcasts, newsletters, or listing pages that cover
    PromptBar as their primary subject.
  * Crop, scale, or place assets on backgrounds that preserve their
    visual quality.

Please do not:

  * Modify the app icon shape, color, or gradient.
  * Composite the icon into another product mark or app icon.
  * Use PromptBar's name or icon in a way that implies endorsement
    or partnership without written permission.

Screenshots reflect a real PromptBar 2.0 build. UI copy and details
may drift in future versions; grab the newest kit from
https://promptbar.peterdsp.dev/press.html when in doubt.

Contact
-------
Petros Dhespollari, developer and maintainer.
Email: info@peterdsp.dev
Website: https://peterdsp.dev
